<!doctype html>
  <!-- ./st4zz Project -->
  <!-- Mau Ngintip Yah Mas? -->
  <!-- Mau Ngintip Yah Mas? -->
  <!-- Mau Ngintip Yah Mas? -->
<html lang="en">
  <head>
  <!-- Header -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#6c757d" />
  <meta name="msapplication-navbutton-color" content="#6c757d" />
  <meta name="msapplication-TileColor" content="#6c757d"/>
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="#6c757d" />
  <title>Mirror Project – Direct Download Link Project</title>
  <meta name="google-site-verification" content="" />
  <meta name="description" content="Direct Download Link Project - Web generate direct link download google drive, dropbox, dan mega.nz" />
  <link rel="canonical" href="https://<?= $_SERVER['HTTP_HOST'] ?>/mirror/" />
  <meta property="og:title" content="Mirror Project – Direct Download Link Project" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://<?= $_SERVER['HTTP_HOST'] ?>/mirror/" />
  <meta property="og:site_name" content="Direct Download Link Project" />
  <meta property="og:author" content="st4zz" />
  <meta property="og:description" content="Direct Download Link Project - Web generate direct link download google drive, dropbox, dan mega.nz" />
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.0/css/all.css" />
  <!-- Favicon -->
  <link rel="shortcut icon" href="/favicon.ico" type="img/x-icon"/>
  <link rel="icon" href="/favicon.ico" type="image/x-icon"/>
  <!-- Stylesheet -->
<style>
@import url(https://fonts.googleapis.com/css?family=Ubuntu:400,700);
@import url(https://fonts.googleapis.com/css?family=Play:400,700);
@import url(https://fonts.googleapis.com/css?family=Lobster:400,700);
@import url(https://fonts.googleapis.com/css?family=Josefin+Sans:400,700);
@import url(https://fonts.googleapis.com/css?family=Ropa+Sans:400,700);
@import url(https://fonts.googleapis.com/css?family=Kaushan+Script:400,700);

html {
	position: relative;
}

body {
	word-wrap: break-word;
	font-family: Ubuntu;
	background: url("https://dl.dropboxusercontent.com/sh/d8na0417pdn36e0/AACj5zzuk_2RBPAXvzlMso-fa/map-bg.png") 50% 0 repeat;
	background-size: 462px;
}

nav {
	font-family: Lobster;
	text-decoration: none;
	text-shadow: 1px 1px 11px #000;
}

.alert-warning {
	font-family: Ropa Sans;
}

.alert-warning h5 {
	font-family: Ropa Sans;
	font-weight: bold;
}

.alert-dark {
	font-family: Josefin Sans;
}

.bg-dark {
	font-family: Ubuntu;
	color: #fff;
}

.bg-dark:hover {
	color: #fff;
}

.bg-stz {
	font-family: Josefin Sans;
	font-size: 15px;
	background-color: #1d212485;
	color: #fff;
	text-shadow: 1px 1px 11px #000;
}

.bg-stz:hover {
	color: #fff;
}

.bg-where {
	font-family: Play;
	background-color: #d4edda85;
	color: #000;
	border: solid 2px #155724;
}

.direct {
	font-family: Play;
}

.direct h4 {
	font-family: Lobster;
	text-decoration: none;
	text-shadow: 1px 1px 10px #6c757d;
}

button a {
	color:#fff;
	text-shadow: 1px 1px 10px #000;
}

button a:hover {
	color:#000;
	text-shadow: 1px 1px 10px #fff;
}

.input-group-text {
	word-wrap: break-word;
	font-family: Ubuntu;
}

footer, footer a {
	color:#fff;
	text-shadow: 1px 1px 11px #000;
}
</style>
  <!-- JavaScript Replace HTTP to HTTPS -->
<script language="javascript" type="text/javascript">
if (location.protocol != 'https:')
{
 location.href = 'https:' + window.location.href.substring(window.location.protocol.length);
}
    </script>
  </head>
<body>
  <!-- Navigation Bar -->
<nav class="navbar top navbar-expand-lg navbar-dark bg-secondary">
<div class="container">
<a class="navbar-brand" href="/"><i class="fas fa-home"></i> Direct Download Link Project</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="navbarNav"><ul class="navbar-nav">
<li class="nav-item"><a class="nav-link" href="https://github.com/st4zzc0de/gdrive" target="_blank"><i class="fab fa-github"></i> My Repository</a></li>
<li class="nav-item"><a class="nav-link" href="/mirror/"><i class="fas fa-clone"></i> Mirror Project</a></li>
</ul>
</div>
</div>
</nav>
  <!-- All My Mirror Project -->
<section class="direct mb-2">
<div class="container">
<div class="row pt-3 justify-content-center">
<div class="col-lg-8">
<ul class="list-group">
  <li class="list-group-item bg-secondary"><h4><i class="fas fa-angle-double-down"></i> All Mirror Direct Project</h4></li>
  <li class="list-group-item"><i class="fas fa-external-link-alt"></i> <a href="https://getdl.herokuapp.com" target="_blank">https://getdl.herokuapp.com</a> <span class="badge badge-primary badge-pill">01</span></li>
  <li class="list-group-item"><i class="fas fa-external-link-alt"></i> <a href="https://gddl.herokuapp.com" target="_blank">https://gddl.herokuapp.com</a> <span class="badge badge-primary badge-pill">02</span></li>
  <li class="list-group-item"><i class="fas fa-external-link-alt"></i> <a href="https://gd7.herokuapp.com" target="_blank">https://gd7.herokuapp.com</a> <span class="badge badge-primary badge-pill">03</span></li>
  <li class="list-group-item"><i class="fas fa-external-link-alt"></i> <a href="https://gd8.herokuapp.com" target="_blank">https://gd8.herokuapp.com</a> <span class="badge badge-primary badge-pill">04</span></li>
  <li class="list-group-item"><i class="fas fa-external-link-alt"></i> <a href="https://gd9.herokuapp.com" target="_blank">https://gd9.herokuapp.com</a> <span class="badge badge-primary badge-pill">05</span></li>
  <li class="list-group-item"><i class="fas fa-external-link-alt"></i> <a href="https://gd0.herokuapp.com" target="_blank">https://gd0.herokuapp.com</a> <span class="badge badge-primary badge-pill">06</span></li>
</ul>
</div>
</div>
<hr/>
<!-- Notes -->
<div class="row justify-content-center">
<div class="col-lg-8">
<div class="alert bg-stz mt-2" role="alert">
<p><h4><i class="fas fa-edit"></i> Catatan</h4></p>
<p>Web ini hanyalah proyek iseng sederhana yang ane buat karena kebosanan yang melanda fikiran ane :v , dan kegunaan web ini adalah cuma untuk generate direct link download dari situs Google Drive & Dropbox.</p>
<p>Sesuai dari informasi diatas bahwa ini hanyalah proyek sederhana, jadi disini ane hanya memanfaatkan <i>$_GET</i> & <i>$_POST</i> dari fitur bawaan PHP saja dan tidak memakai sebuah API ataupun Database.</p>
Jika ane memiliki keinginan lain disaat bosan mungkin ane akan mengembangkan proyek ini dan akan menambahkan direct link lain seperti Zippyshare, One Drive, atau lainnya.</div>
</div>
</div>
</div>
</section>
  <!-- Footer -->
<footer class="bg-secondary mt-3 text-white">
<div class="container">
<div class="row pt-2 pb-2">
<div class="col text-center">
&copy; <script>document.write(new Date().getFullYear());</script> – <b>Direct Download Link Project</b>
</div>
</div>
</div>
</footer>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</body>
</html>