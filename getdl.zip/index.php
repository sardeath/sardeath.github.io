<?php
// Direct Link Download Project by st4zz

// Function Grabbing
function ngegrab($url){
    $curl = curl_init();
     $header[0] = "Accept: text/xml,application/xml,application/xhtml+xml,";
    $header[0] .= "text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5";
    $header[] = "Cache-Control: max-age=0";
    $header[] = "Connection: keep-alive";
    $header[] = "Keep-Alive: 300";
    $header[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $header[] = "Accept-Language: en-us,en;q=0.5";
    $header[] = "Pragma: ";
    $referer = "http://www.google.com";
    $btext = rand(0,99999);
    $browser = 'Mozilla/5.0' . $btext;
 
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERAGENT, $browser);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curl, CURLOPT_REFERER, $referer);
    curl_setopt($curl, CURLOPT_AUTOREFERER, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 60);
    curl_setopt($curl, CURLOPT_MAXREDIRS, 14);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
return curl_exec($curl);
  curl_close($curl);
}
function grab($url)
{
$ua="Nokia6020/2.0 (04.90) Profile/MIDP-2.0 Cofiguration/CLDC-1.1";
$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_USERAGENT,$ua);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
$exec=curl_exec($ch);
return $exec;
}
// Function Cut
function cut($content,$start,$end){
if($content && $start && $end) {
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];}
return '';}
}

// GET GDrive URL Method
$gdurl = $_POST['d'];

// GET Dropbox URL Method
$dburl = $_POST['db'];
$dblink = cut($dburl,'https://www.dropbox.com','?dl=0');

// GET Mega URL Method
$idmega = $_POST['m'];
$idmegaku = str_replace('mega.nz/!', 'mega.nz/#!', $idmega);

// Function Mega Nz
$url = "$idmegaku";
preg_match("/!(.+?)!/", $url, $output_array);
$fileID = $output_array[1];
$domain = "meganz";
$lang = "en";
$apiURL = "https://eu.api.mega.co.nz/cs?domain=$domain&lang=$lang";
 
$value = array(
  array(
    'a' => 'g',
    'g' => 1,
    'ssl' => 0, //0, 1, 2 (default is 2)
    'p' => $fileID) // File id here
  );
 
  $rawPOST = json_encode($value);
 
  $ch = curl_init();
 
  curl_setopt($ch, CURLOPT_URL,            $apiURL );
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
  curl_setopt($ch, CURLOPT_POST,           true );
  curl_setopt($ch, CURLOPT_POSTFIELDS,     $rawPOST );
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36');
  curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/plain;charset=UTF-8'));
 
  $result=curl_exec($ch);
 
  $jsonResult = json_decode($result);
  $directLink = $jsonResult[0]->g;
  $fileSize = $jsonResult[0]->s;

// Function GDrive Direct Link /file/d/
$id = cut($gdurl,'/d/','/');
 
 function udud($id){
		$ch = curl_init("https://drive.google.com/uc?id=$id&authuser=0&export=download");
		curl_setopt_array($ch, array(
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_POSTFIELDS => [],
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => 'gzip,deflate',
			CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
			CURLOPT_HTTPHEADER => [
				'accept-encoding: gzip, deflate, br',
				'content-length: 0',
				'content-type: application/x-www-form-urlencoded;charset=UTF-8',
				'origin: https://drive.google.com',
				'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
				'x-client-data: CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=',
				'x-drive-first-party: DriveWebUi',
				'x-json-requested: true'
			]
		));
		$response = curl_exec($ch);
		$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		if($response_code == '200') { // Jika response status OK
			$object = json_decode(str_replace(')]}\'', '', $response));
			if(isset($object->downloadUrl)) {
				return $object->downloadUrl;
			} 
		} else {
			return $response_code;
		}
}
$result = udud($id);

// Grab Info Link /file/d/
$grogolfd = grab('https://www.grogol.us/drive/'.$id.'');
$pecahno = explode('<div class="main_menu"><table>', $grogolfd);
$title = explode('<tr><td class="p_s">Name</td><td class="p_m">', $pecahno[1]);
$title = explode('</td></tr>', $title[1]);
$size = explode('<tr><td class="p_s">Size</td><td class="p_m">', $pecahno[1]);
$size = explode('</td></tr>', $size[1]);
$time = explode('<tr><td class="p_s">Time</td><td class="p_m">', $pecahno[1]);
$time = explode('</td></tr>', $time[1]);


// Function GDrive Direct Link id
$ids = cut($gdurl,'id=','/');
 
 function ududs($ids){
		$ch = curl_init("https://drive.google.com/uc?id=$ids&authuser=0&export=download");
		curl_setopt_array($ch, array(
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_POSTFIELDS => [],
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => 'gzip,deflate',
			CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
			CURLOPT_HTTPHEADER => [
				'accept-encoding: gzip, deflate, br',
				'content-length: 0',
				'content-type: application/x-www-form-urlencoded;charset=UTF-8',
				'origin: https://drive.google.com',
				'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
				'x-client-data: CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=',
				'x-drive-first-party: DriveWebUi',
				'x-json-requested: true'
			]
		));
		$response = curl_exec($ch);
		$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		if($response_code == '200') { // Jika response status OK
			$object = json_decode(str_replace(')]}\'', '', $response));
			if(isset($object->downloadUrl)) {
				return $object->downloadUrl;
			} 
		} else {
			return $response_code;
		}
}
$results = ududs($ids);

// Grab Info Link id
$grogolid = grab('https://www.grogol.us/drive/'.$ids.'');
$pecahin = explode('<div class="main_menu"><table>', $grogolid);
$judul = explode('<tr><td class="p_s">Name</td><td class="p_m">', $pecahin[1]);
$judul = explode('</td></tr>', $judul[1]);
$ukuran = explode('<tr><td class="p_s">Size</td><td class="p_m">', $pecahin[1]);
$ukuran = explode('</td></tr>', $ukuran[1]);
$waktu = explode('<tr><td class="p_s">Time</td><td class="p_m">', $pecahin[1]);
$waktu = explode('</td></tr>', $waktu[1]);
?>
<!doctype html>
  <!-- ./st4zz Project -->
  <!-- Mau Ngintip Yah Mas? -->
  <!-- Mau Ngintip Yah Mas? -->
  <!-- Mau Ngintip Yah Mas? -->
<html lang="en">
  <head>
  <!-- Header -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#6c757d" />
  <meta name="msapplication-navbutton-color" content="#6c757d" />
  <meta name="msapplication-TileColor" content="#6c757d"/>
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="#6c757d" />
  <title>Direct Download Link Project</title>
  <meta name="google-site-verification" content="" />
  <meta name="description" content="Direct Download Link Project - Web generate direct link download google drive, dropbox, dan mega.nz" />
  <link rel="canonical" href="https://<?= $_SERVER['HTTP_HOST'] ?>" />
  <meta property="og:title" content="Direct Download Link Project" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://<?= $_SERVER['HTTP_HOST'] ?>" />
  <meta property="og:image" content="https://i.ibb.co/sgY1R5t/thumb-stz.png" />
  <meta property="og:site_name" content="Direct Download Link Project" />
  <meta property="og:author" content="st4zz" />
  <meta property="og:description" content="Direct Download Link Project - Web generate direct link download google drive, dropbox, dan mega.nz" />
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.0/css/all.css" />
  <!-- Favicon -->
  <link rel="shortcut icon" href="/favicon.ico" type="img/x-icon"/>
  <link rel="icon" href="/favicon.ico" type="image/x-icon"/>
  <!-- Stylesheet -->
<style>
@import url(https://fonts.googleapis.com/css?family=Ubuntu:400,700);
@import url(https://fonts.googleapis.com/css?family=Play:400,700);
@import url(https://fonts.googleapis.com/css?family=Lobster:400,700);
@import url(https://fonts.googleapis.com/css?family=Josefin+Sans:400,700);
@import url(https://fonts.googleapis.com/css?family=Ropa+Sans:400,700);
@import url(https://fonts.googleapis.com/css?family=Kaushan+Script:400,700);

html {
	position: relative;
}

body {
	word-wrap: break-word;
	font-family: Ubuntu;
	background: url("https://dl.dropboxusercontent.com/sh/d8na0417pdn36e0/AACj5zzuk_2RBPAXvzlMso-fa/map-bg.png") 50% 0 repeat;
	background-size: 462px;
}

nav {
	font-family: Lobster;
	text-decoration: none;
	text-shadow: 1px 1px 11px #000;
}

.alert-warning {
	font-family: Ropa Sans;
}

.alert-warning h5 {
	font-family: Ropa Sans;
	font-weight: bold;
}

.alert-dark {
	font-family: Josefin Sans;
}

.bg-dark {
	font-family: Ubuntu;
	color: #fff;
}

.bg-dark:hover {
	color: #fff;
}

.bg-stz {
	font-family: Josefin Sans;
	font-size: 15px;
	background-color: #1d212485;
	color: #fff;
	text-shadow: 1px 1px 11px #000;
}

.bg-stz:hover {
	color: #fff;
}

.bg-where {
	font-family: Play;
	background-color: #d4edda85;
	color: #000;
	border: solid 2px #155724;
}

.direct {
	font-family: Play;
}

.direct h4 {
	font-family: Lobster;
	text-decoration: none;
	text-shadow: 1px 1px 10px #6c757d;
}

button a {
	color:#fff;
	text-shadow: 1px 1px 10px #000;
}

button a:hover {
	color:#000;
	text-shadow: 1px 1px 10px #fff;
}

.input-group-text {
	word-wrap: break-word;
	font-family: Ubuntu;
}

footer, footer a {
	color:#fff;
	text-shadow: 1px 1px 11px #000;
}
</style>
  <!-- JavaScript Replace HTTP to HTTPS -->
<script language="javascript" type="text/javascript">
if (location.protocol != 'https:')
{
 location.href = 'https:' + window.location.href.substring(window.location.protocol.length);
}
    </script>
  </head>
<body>
  <!-- Navigation Bar -->
<nav class="navbar top navbar-expand-lg navbar-dark bg-secondary">
<div class="container">
<a class="navbar-brand" href="/"><i class="fas fa-home"></i> Direct Download Link Project</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="navbarNav"><ul class="navbar-nav">
<li class="nav-item"><a class="nav-link" href="https://github.com/st4zzc0de/gdrive" target="_blank"><i class="fab fa-github"></i> My Repository</a></li>
<li class="nav-item"><a class="nav-link" href="/mirror/"><i class="fas fa-clone"></i> Mirror Project</a></li>
</ul>
</div>
</div>
</nav>
  <!-- Google Drive Generate Link -->
<section class="direct mb-2">
<div class="container">
<div class="row pt-3">
<div class="col text-center" id="gdrive">
<h4 style="color: #28a745"><i class="fab fa-google-drive"></i> Direct Link Google Drive</h4>
</div>
</div>
<div class="row justify-content-center">
<div class="col-lg-8">
<div class="alert alert-warning" role="alert">
<h5><i class="fas fa-exclamation-circle"></i> ATURAN PAKAI :</h5>
<i class="fas fa-angle-right"></i> Masukan link google drive yang benar agar link direct downloadnya dapat diproses.<br/>
<i class="fas fa-angle-right"></i> Pastikan juga link google drive yg ingin di generate tidak berstatus limit kuota atau dihapus.</div>
</div>
</div>
<div class="row justify-content-center">
<div class="col-lg-8">
<form method="post">
<div class="alert alert-success text-center" role="alert">
<p align="center"><input class="form-control" name="d" type="text" id="d" placeholder="Masukan URL Google Drive..." /></p>
<center><form method="post"><input type="submit" class="btn btn-success" value="GENERATE" />
</form></center>
</div>
<?php
if ($id) {
echo '<div class="alert alert-success" role="alert">
<table class="table table-striped table-bordered table-success">
  <thead>
    <tr>
      <h4 class="text-center">Informasi File</h4>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Nama</th>
      <td>'.$title[0].'</td>
    </tr>
    <tr>
      <th scope="row">Ukuran</th>
      <td>'.$size[0].'</td>
    </tr>
    <tr>
      <th scope="row">Diupload</th>
      <td>'.$time[0].'</td>
    </tr>
  </tbody>
</table>
<p align="center"><i class="fas fa-check-circle"></i> Direct Link Result : <br/>
<input class="form-control" name="d" type="text" id="d" value="'.$result.'" onclick="this.select();" /></form>
<i>(#NOTE: Link diatas tidak permanen dan bisa berubah tergantung IP dan browser)</i><br/>
<button class="btn btn-success"><a href="'.$result.'"><i class="fas fa-cloud-download-alt"></i> Klik Untuk Unduh</a></button></p>
<hr />
<p align="center"><i>(#NOTE: Jika direct link error <b>403</b> karena di block oleh Google, gunakan link unduh aslinya dibawah ini)</i><br/>
<button class="btn btn-success"><a href="https://drive.google.com/uc?id='.$id.'&export=download" target="_blank"><i class="fas fa-cloud-download-alt"></i> Unduh Via Original Link</a></button></p>
<hr />
<p align="center"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#alter">
  <i class="fas fa-angle-double-down"></i> Rekomendasi Metode Sederhana
</button></p>
<div class="modal fade" id="alter" tabindex="-1" role="dialog" aria-labelledby="alterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="alterTitle"><i class="fas fa-angle-double-down"></i> Metode Sederhana</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close Tips">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<p align="left"><b><i class="fas fa-exclamation-circle"></i> Alternatif</b><br />
Kamu juga bisa gunakan mode generate cepat ini.<br/>
<textarea class="form-control bg-dark" disabled>https://'.$_SERVER['HTTP_HOST'].'/dl/ID-GDRIVE</textarea>
<i>(cukup hanya menambahkan path link <b>/dl/</b> dan <b>ID-GDRIVE</b> saja).</i></p>
<p align="left"><b><i class="fas fa-exclamation-circle"></i> Dimana ID Google Drive?</b>
<div class="alert bg-where text-left" role="alert">https://drive.google.com/file/d/<b>'.$id.'</b>/view
<hr />
(#NOTE: teks tebal diatas adalah ID Google Drive)</div></p>
<p align="left"><b><i class="fas fa-exclamation-circle"></i> Contoh Pemakaian :</b><br/>
<textarea class="form-control alert-secondary">https://'.$_SERVER['HTTP_HOST'].'/dl/'.$id.'</textarea></p>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Close Tips</button>
      </div>
    </div>
  </div>
</div>
</div>';
}
elseif ($ids) {
echo '<div class="alert alert-success" role="alert">
<table class="table table-striped table-bordered table-success">
  <thead>
    <tr>
      <h4 class="text-center">Informasi File</h4>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Nama</th>
      <td>'.$judul[0].'</td>
    </tr>
    <tr>
      <th scope="row">Ukuran</th>
      <td>'.$ukuran[0].'</td>
    </tr>
    <tr>
      <th scope="row">Diupload</th>
      <td>'.$waktu[0].'</td>
    </tr>
  </tbody>
</table>
<p align="center"><i class="fas fa-check-circle"></i> Direct Link Result : <br/>
<input class="form-control" name="d" type="text" id="d" value="'.$results.'" onclick="this.select();" /></form>
<i>(#NOTE: Link diatas tidak permanen dan bisa berubah tergantung IP)</i><br/>
<button class="btn btn-success"><a href="'.$results.'"><i class="fas fa-cloud-download-alt"></i> Klik Untuk Unduh</a></button></p>
<hr />
<p align="center"><i>(#NOTE: Jika direct link error <b>403</b> karena di block oleh Google, gunakan link unduh aslinya dibawah ini)</i><br/>
<button class="btn btn-success"><a href="https://drive.google.com/uc?id='.$ids.'&export=download" target="_blank"><i class="fas fa-cloud-download-alt"></i> Unduh Via Original Link</a></button></p>
<hr />
<p align="center"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#alter">
  <i class="fas fa-angle-double-down"></i> Rekomendasi Metode Sederhana
</button></p>
<div class="modal fade" id="alter" tabindex="-1" role="dialog" aria-labelledby="alterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="alterTitle"><i class="fas fa-angle-double-down"></i> Metode Sederhana</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close Tips">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<p align="left"><b><i class="fas fa-exclamation-circle"></i> Alternatif</b><br/>
Kamu juga bisa gunakan mode generate cepat ini.<br/>
<textarea class="form-control bg-dark" disabled>https://'.$_SERVER['HTTP_HOST'].'/dl/ID-GDRIVE</textarea>
<i>(cukup hanya menambahkan path link <b>/dl/</b> dan <b>ID-GDRIVE</b> saja).</i></p>
<p align="left"><b><i class="fas fa-exclamation-circle"></i> Dimana ID Google Drive?</b>
<div class="alert bg-where text-left" role="alert">https://drive.google.com/open?id=<b>'.$ids.'</b>
<hr />
(#NOTE: teks tebal diatas adalah ID Google Drive)</div></p>
<p align="left"><b><i class="fas fa-exclamation-circle"></i> Contoh Pemakaian :</b><br/>
<textarea class="form-control alert-secondary">https://'.$_SERVER['HTTP_HOST'].'/dl/'.$ids.'</textarea></p>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Close Tips</button>
      </div>
    </div>
  </div>
</div>
</div>';
	}
elseif ($gdurl != $id) {
	echo '<div class="alert alert-danger" role="alert"><p><b><i class="fas fa-exclamation-triangle"></i> Link Google Drive yang kamu masukan salah, silahkan lihat contoh linknya dibawah ini.</b></p>
<i class="fas fa-exclamation-circle"></i> CONTOH LINK YANG BENAR :<br/>
<textarea rows="3" class="form-control alert-danger">https://drive.google.com/file/d/1BP55XZethh7yLzw43D7TC-hae9YMkYwC/view</textarea>
<center>ATAU</center>
<textarea rows="3" class="form-control alert-danger">https://drive.google.com/open?id=1BP55XZethh7yLzw43D7TC-hae9YMkYwC</textarea>
</div>';
	}
else{
	echo '';
}
echo '</div>
</section>';

echo '<hr/>
<!-- Dropbox Generate Link -->
<section class="direct mb-2">
<div class="container">
<div class="row pt-2">
<div class="col text-center" id="dropbox">
<h4 style="color: #007bff"><i class="fab fa-dropbox"></i> Direct Link Dropbox</h4>
</div>
</div>
<div class="row justify-content-center">
<div class="col-lg-8">
<div class="alert alert-warning" role="alert">
<h5><i class="fas fa-exclamation-circle"></i> ATURAN PAKAI :</h5>
<i class="fas fa-angle-right"></i> Masukan link dropbox yang benar agar link direct downloadnya dapat diproses.<br/>
<i class="fas fa-angle-right"></i> Pastikan juga link dropbox tersebut aktif dan filenya tidak dihapus.</div>
</div>
</div>
<div class="row justify-content-center">
<div class="col-lg-8">
<form method="post">
<div class="alert alert-primary text-center" role="alert">
<p align="center"><input class="form-control" name="db" type="text" id="db" placeholder="Masukan URL Dropbox..." /></p>
<center><form method="post"><input type="submit" class="btn btn-primary" value="GENERATE" />
</form></center></div>';

if ($dblink) {
echo '<div class="alert alert-primary text-center" role="alert"><i class="fas fa-check-circle"></i> Direct Link Result : <br/>
<input class="form-control" name="db" type="text" id="db" value="https://dl.dropboxusercontent.com'.$dblink.'" onclick="this.select();" /></form>
<i>(#NOTE: Link Ini Permanen)</i><br/>
<button class="btn btn-primary"><a href="https://dl.dropboxusercontent.com'.$dblink.'"><i class="fas fa-cloud-download-alt"></i> Klik Untuk Unduh</a></button>
</div>';
}
elseif ($dburl != $dblink) {
	echo '<div class="alert alert-danger" role="alert"><p><b><i class="fas fa-exclamation-triangle"></i> Link Dropbox yang kamu masukan salah, silahkan lihat contoh linknya dibawah ini.</b></p>
<i class="fas fa-exclamation-circle"></i> CONTOH LINK YANG BENAR :<br/>
<textarea rows="5" class="form-control alert-danger">https://www.dropbox.com/sh/fxj2wut7r84ouly/AABeTuovUs8wxc8cB4C8lTvHa/ONE%20OK%20ROCK%202018%20AMBITIONS%20JAPAN%20DOME%20TOUR.mkv?dl=0</textarea>
<center>ATAU</center>
<textarea rows="5" class="form-control alert-danger">https://www.dropbox.com/s/9p1b5g4g2mb591n/ONE%20OK%20ROCK%202018%20AMBITIONS%20JAPAN%20DOME%20TOUR.mkv?dl=0</textarea>
</div>';
	}
else{
	echo '';
}

if (empty($_POST)) {
echo '<hr/>
<!-- Notes -->
<div class="alert bg-stz mt-2" role="alert"><p><h4><i class="fas fa-edit"></i> Catatan</h4></p>
<p>Web ini hanyalah proyek iseng sederhana yang ane buat karena kebosanan yang melanda fikiran ane :v , dan kegunaan web ini adalah cuma untuk generate direct link download dari situs Google Drive & Dropbox.</p>
<p>Sesuai dari informasi diatas bahwa ini hanyalah proyek sederhana, jadi disini ane hanya memanfaatkan <i>$_GET</i> & <i>$_POST</i> dari fitur bawaan PHP saja dan tidak memakai sebuah API ataupun Database.</p>
Jika ane memiliki keinginan lain disaat bosan mungkin ane akan mengembangkan proyek ini dan akan menambahkan direct link lain seperti Zippyshare, One Drive, atau lainnya.</div>';
}
else{
echo '';
}
?>
</div>
</section>
  <!-- Footer -->
<footer class="bg-secondary mt-3 text-white">
<div class="container">
<div class="row pt-2 pb-2">
<div class="col text-center">
&copy; <script>document.write(new Date().getFullYear());</script> – <b>Direct Download Link Project</b>
</div>
</div>
</div>
</footer>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</body>
</html>